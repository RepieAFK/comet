<?php $__env->startSection('title', 'Detail Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Peminjaman</h1>
    <a href="<?php echo e(route('peminjaman.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-2"></i>Kembali
    </a>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Informasi Peminjaman</h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">ID Peminjaman</div>
                    <div class="col-md-8"><?php echo e($peminjaman->id); ?></div>
                </div>
                
                <?php if(auth()->user()->isAdmin() || auth()->user()->isPetugas()): ?>
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Peminjam</div>
                    <div class="col-md-8"><?php echo e($peminjaman->user->name); ?> (<?php echo e($peminjaman->user->nomor_induk); ?>)</div>
                </div>
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Ruangan</div>
                    <div class="col-md-8"><?php echo e($peminjaman->ruangan->nama_ruangan); ?></div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Lokasi</div>
                    <div class="col-md-8"><?php echo e($peminjaman->ruangan->lokasi); ?></div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Waktu Mulai</div>
                    <div class="col-md-8"><?php echo e($peminjaman->tanggal ? $peminjaman->tanggal->format('d-m-Y') : '-'); ?></div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Waktu Selesai</div>
                    <div class="col-md-8"><?php echo e($peminjaman->tanggal ? $peminjaman->tanggal->addHours($peminjaman->waktu_selesai)->format('d-m-Y H:i') : '-'); ?></div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Keperluan</div>
                    <div class="col-md-8"><?php echo e($peminjaman->keperluan); ?></div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Status</div>
                    <div class="col-md-8">
                        <span class="status-badge status-<?php echo e($peminjaman->status); ?>">
                            <?php echo e(ucfirst($peminjaman->status)); ?>

                        </span>
                    </div>
                </div>
                
                <?php if($peminjaman->catatan): ?>
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Catatan</div>
                    <div class="col-md-8"><?php echo e($peminjaman->catatan); ?></div>
                </div>
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Tanggal Pengajuan</div>
                    <div class="col-md-8"><?php echo e($peminjaman->created_at->format('d F Y H:i')); ?></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <?php if($peminjaman->ruangan->foto): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Foto Ruangan</h5>
            </div>
            <div class="card-body p-0">
                <img src="<?php echo e(asset('uploads/ruangan/' . $peminjaman->ruangan->foto)); ?>" 
                     class="img-fluid" alt="<?php echo e($peminjaman->ruangan->nama_ruangan); ?>">
            </div>
        </div>
        <?php endif; ?>
        
        <?php if(auth()->user()->isAdmin() || auth()->user()->isPetugas()): ?>
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="mb-0">Aksi</h5>
            </div>
            <div class="card-body">
                <?php if($peminjaman->status == 'menunggu'): ?>
                    <a href="<?php echo e(route('peminjaman.edit', $peminjaman)); ?>" class="btn btn-warning btn-sm w-100 mb-2">
                        <i class="fas fa-edit me-1"></i> Edit
                    </a>
                    
                    <form action="<?php echo e(route('peminjaman.approve', $peminjaman)); ?>" method="POST" class="mb-2">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-2">
                            <textarea name="catatan" class="form-control" placeholder="Catatan (opsional)"></textarea>
                        </div>
                        <button type="submit" class="btn btn-success btn-sm w-100">
                            <i class="fas fa-check me-1"></i> Setujui
                        </button>
                    </form>
                    
                    <form action="<?php echo e(route('peminjaman.reject', $peminjaman)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-2">
                            <textarea name="catatan" class="form-control" placeholder="Alasan penolakan" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-danger btn-sm w-100">
                            <i class="fas fa-times me-1"></i> Tolak
                        </button>
                    </form>
                <?php endif; ?>
                
                <?php if(in_array($peminjaman->status, ['menunggu', 'disetujui'])): ?>
                    <form action="<?php echo e(route('peminjaman.destroy', $peminjaman)); ?>" method="POST" class="mt-2">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm w-100" onclick="return confirm('Apakah Anda yakin?')">
                            <i class="fas fa-trash me-1"></i> Hapus
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\FullUKK\LastUKK\resources\views\peminjaman\show.blade.php ENDPATH**/ ?>