<?php $__env->startSection('title', 'Jadwal Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <!-- Page Header -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Jadwal Peminjaman</h1>
            <p class="text-muted mb-0">Menampilkan semua jadwal peminjaman ruangan</p>
        </div>
        <div>
            <a href="<?php echo e(route('jadwal_reguler.index')); ?>" class="btn btn-warning btn-sm">
                <i class="fas fa-calendar-plus me-2"></i>Atur Jadwal Reguler
            </a>
        </div>
    </div>

    <!-- Schedule Card -->
    <div class="card shadow mb-4" data-aos="fade-up" data-aos-delay="100">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <div>
                <h6 class="m-0 font-weight-bold text-primary">Daftar Peminjaman</h6>
            </div>
            <div class="d-flex gap-2">
                <span class="badge bg-primary px-3 py-2">
                    <i class="fas fa-info-circle me-1"></i><?php echo e(now()->format('d M Y')); ?>

                </span>
            </div>
        </div>
        
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered m-0">
                    <thead class="bg-gradient-primary text-white">
                        <tr>
                            <th class="text-center" width="5%">No</th>
                            <th width="15%">Ruangan & Lokasi</th>
                            <th width="15%">Peminjam</th>
                            <th width="12%">Hari</th>
                            <th width="12%">Sesi</th>
                            <th width="12%">Waktu</th>
                            <th width="15%">Keperluan</th>
                            <th width="8%">Status</th>
                            <th class="text-center" width="6%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $data = $peminjamanByHariSesi ?? [];
                            $groupedData = [];
                            
                            // Group by date for better organization
                            foreach ($data as $key => $peminjamanList) {
                                $peminjaman = $peminjamanList[0];
                                $dateKey = $peminjaman->waktu_mulai->format('Y-m-d');
                                
                                if (!isset($groupedData[$dateKey])) {
                                    $groupedData[$dateKey] = [
                                        'date' => $peminjaman->waktu_mulai,
                                        'bookings' => []
                                    ];
                                }
                                $groupedData[$dateKey]['bookings'][] = [
                                    'key' => $key,
                                    'list' => $peminjamanList
                                ];
                            }
                            
                            ksort($groupedData);
                        ?>
                        
                        <?php if(count($data) > 0): ?>
                            <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dateGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isToday = $dateGroup['date']->isToday();
                                ?>
                                
                                <!-- Date Section Header -->
                                <tr class="bg-light border-top-2 border-dark">
                                    <td colspan="9" class="fw-bold py-2 px-3">
                                        <div class="d-flex align-items-center gap-2">
                                            <i class="fas <?php echo e($isToday ? 'fa-calendar-check text-success' : 'fa-calendar-alt text-primary'); ?>"></i>
                                            <span class="fs-6">
                                                <?php echo e($dateGroup['date']->format('l, d F Y')); ?>

                                                <?php if($isToday): ?>
                                                    <span class="badge bg-success ms-2">HARI INI</span>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                
                                <?php $__currentLoopData = $dateGroup['bookings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $sesiKey = explode('-', $booking['key']);
                                        $sesiNum = count($sesiKey) > 1 ? $sesiKey[1] : 'N/A';
                                        $sesiList = getSesiList();
                                        $sesiTime = $sesiNum !== 'N/A' && isset($sesiList[$sesiNum]) ? $sesiList[$sesiNum] : ['N/A', 'N/A'];
                                        $peminjaman = $booking['list'][0];
                                        
                                        // Status badge styling
                                        $status = $peminjaman->status ?? 'pending';
                                        $statusClasses = [
                                            'disetujui' => 'bg-success',
                                            'ditolak' => 'bg-danger',
                                            'selesai' => 'bg-info',
                                            'menunggu' => 'bg-warning',
                                            'batal' => 'bg-secondary'
                                        ];
                                        $statusClass = $statusClasses[$status] ?? 'bg-secondary';
                                        
                                        // Icon based on status
                                        $statusIcon = match($status) {
                                            'disetujui' => 'check-circle',
                                            'ditolak' => 'times-circle',
                                            'selesai' => 'flag-checkered',
                                            'menunggu' => 'clock',
                                            'batal' => 'ban',
                                            default => 'question-circle'
                                        };
                                    ?>
                                    
                                    <tr data-id="<?php echo e($peminjaman->id); ?>" 
                                        class="<?php echo e($isToday ? 'table-warning' : ''); ?>"
                                        style="transition: all 0.2s ease;">
                                        <td class="text-center fw-bold"><?php echo e($loop->parent->iteration); ?>.<?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <span class="fw-bold text-primary">
                                                    <?php echo e($peminjaman->ruangan->nama_ruangan ?? 'N/A'); ?>

                                                </span>
                                                <small class="text-muted">
                                                    <i class="fas fa-map-marker-alt me-1"></i>
                                                    <?php echo e($peminjaman->ruangan->lokasi ?? 'N/A'); ?>

                                                </small>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" 
                                                     style="width: 30px; height: 30px;">
                                                    <?php echo e(strtoupper(substr($peminjaman->user->name ?? 'U', 0, 1))); ?>

                                                </div>
                                                <div>
                                                    <div class="fw-medium"><?php echo e($peminjaman->user->name ?? 'N/A'); ?></div>
                                                    <small class="text-muted"><?php echo e($peminjaman->user->email ?? ''); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark px-3 py-2">
                                                <?php echo e($peminjaman->waktu_mulai->format('l')); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <span class="badge bg-gradient-primary text-white px-3 py-2 mb-1">
                                                    Sesi <?php echo e($sesiNum); ?>

                                                </span>
                                                <small class="text-muted text-center">
                                                    <?php echo e($sesiTime[0] ?? 'N/A'); ?> - <?php echo e($sesiTime[1] ?? 'N/A'); ?>

                                                </small>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-center">
                                                <div class="fw-semibold">
                                                    <?php echo e($peminjaman->waktu_mulai->format('H:i')); ?>

                                                </div>
                                                <div class="text-muted small">→</div>
                                                <div class="fw-semibold">
                                                    <?php echo e($peminjaman->waktu_selesai->format('H:i')); ?>

                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="position-relative" style="max-width: 200px;">
                                                <?php if(is_array($peminjaman->keperluan)): ?>
                                                    <?php $__currentLoopData = explode(', ', implode(', ', $peminjaman->keperluan)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge bg-light text-dark me-1 mb-1">
                                                            <?php echo e(trim($item)); ?>

                                                        </span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <span class="badge bg-light text-dark px-2 py-1">
                                                        <?php echo e($peminjaman->keperluan ?? 'N/A'); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="d-flex flex-column align-items-center">
                                                <span class="badge <?php echo e($statusClass); ?> px-3 py-2 mb-1">
                                                    <i class="fas fa-<?php echo e($statusIcon); ?> me-1"></i>
                                                    <?php echo e(ucfirst($status)); ?>

                                                </span>
                                                <small class="text-muted">
                                                    <?php echo e($peminjaman->waktu_mulai->diffForHumans()); ?>

                                                </small>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group-vertical btn-group-sm" role="group">
                                                <a href="<?php echo e(route('peminjaman.show', $peminjaman)); ?>" 
                                                   class="btn btn-outline-primary btn-sm"
                                                   data-bs-toggle="tooltip" 
                                                   data-bs-placement="top" 
                                                   title="Lihat Detail">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if(auth()->user()->isAdmin() || auth()->user()->isPetugas()): ?>
                                                    <a href="<?php echo e(route('peminjaman.edit', $peminjaman)); ?>" 
                                                       class="btn btn-outline-warning btn-sm"
                                                       data-bs-toggle="tooltip" 
                                                       data-bs-placement="top" 
                                                       title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('peminjaman.destroy', $peminjaman)); ?>" 
                                                          method="POST" 
                                                          class="d-inline delete-form">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" 
                                                                class="btn btn-outline-danger btn-sm delete-btn"
                                                                data-bs-toggle="tooltip" 
                                                                data-bs-placement="top" 
                                                                title="Hapus"
                                                                data-id="<?php echo e($peminjaman->id); ?>">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" class="text-center py-5">
                                    <div class="d-flex flex-column align-items-center">
                                        <div class="rounded-circle bg-light p-4 mb-3">
                                            <i class="fas fa-calendar-times fa-3x text-muted"></i>
                                        </div>
                                        <h5 class="text-muted mb-2">Tidak Ada Jadwal</h5>
                                        <p class="text-muted mb-0 text-center" style="max-width: 400px;">
                                            Tidak ada peminjaman ruangan yang terdaftar untuk saat ini. 
                                            Silakan buat peminjaman baru atau periksa kembali nanti.
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Enhanced delete confirmation
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const form = this.closest('.delete-form');
            
            if (confirm('Apakah Anda yakin ingin menghapus peminjaman ini? Tindakan ini tidak dapat dibatalkan.')) {
                form.submit();
            }
        });
    });

    // Add hover effects for better UX
    document.querySelectorAll('tr[data-id]').forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.backgroundColor = '#f8f9fa';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.backgroundColor = '';
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\FullUKK\LastUKK\resources\views\jadwal.blade.php ENDPATH**/ ?>