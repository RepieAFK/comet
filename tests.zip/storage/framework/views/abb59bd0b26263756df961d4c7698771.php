<?php $__env->startSection('title', 'Detail Ruangan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Ruangan</h1>
    <a href="<?php echo e(route('ruangan.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-2"></i>Kembali
    </a>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Informasi Ruangan</h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Kode Ruangan</div>
                    <div class="col-md-8"><?php echo e($ruangan->kode_ruangan); ?></div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Nama Ruangan</div>
                    <div class="col-md-8"><?php echo e($ruangan->nama_ruangan); ?></div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Kapasitas</div>
                    <div class="col-md-8"><?php echo e($ruangan->kapasitas); ?> orang</div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Lokasi</div>
                    <div class="col-md-8"><?php echo e($ruangan->lokasi); ?></div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Status</div>
                    <div class="col-md-8">
                        <span class="badge bg-<?php echo e($ruangan->status == 'tersedia' ? 'success' : 'danger'); ?>">
                            <?php echo e(ucfirst($ruangan->status)); ?>

                        </span>
                    </div>
                </div>
                
                <?php if($ruangan->deskripsi): ?>
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">Deskripsi</div>
                    <div class="col-md-8"><?php echo e($ruangan->deskripsi); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <?php if($ruangan->foto): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Foto Ruangan</h5>
            </div>
            <div class="card-body p-0">
                <img src="<?php echo e(asset('uploads/ruangan/' . $ruangan->foto)); ?>" 
                     class="img-fluid" alt="<?php echo e($ruangan->nama_ruangan); ?>">
            </div>
        </div>
        <?php endif; ?>
        
        <?php if(auth()->user()->isAdmin()): ?>
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="mb-0">Aksi</h5>
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('ruangan.edit', $ruangan)); ?>" class="btn btn-warning btn-sm w-100 mb-2">
                    <i class="fas fa-edit me-1"></i> Edit
                </a>
                
                <form action="<?php echo e(route('ruangan.destroy', $ruangan)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm w-100" onclick="return confirm('Apakah Anda yakin?')">
                        <i class="fas fa-trash me-1"></i> Hapus
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\FullUKK\LastUKK\resources\views\ruangan\show.blade.php ENDPATH**/ ?>