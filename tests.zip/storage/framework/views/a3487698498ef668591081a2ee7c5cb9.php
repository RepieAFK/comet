<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Dashboard</h1>
</div>

<?php if($user->isAdmin() || $user->isPetugas()): ?>
    <!-- Admin/Petugas Dashboard -->
    <div class="row">
        <div class="col-md-3">
            <div class="card text-bg-primary">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($totalRuangan); ?></h4>
                            <p>Total Ruangan</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-door-open fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-bg-info">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($totalPeminjaman); ?></h4>
                            <p>Total Peminjaman</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-calendar-check fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-bg-warning">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($peminjamanMenunggu); ?></h4>
                            <p>Menunggu Persetujuan</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-bg-success">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($peminjamanHariIni); ?></h4>
                            <p>Peminjaman Hari Ini</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-calendar-day fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <!-- Peminjam Dashboard -->
    <div class="row">
        <div class="col-md-3">
            <div class="card text-bg-primary">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($totalPeminjaman); ?></h4>
                            <p>Total Peminjaman</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-calendar-check fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-bg-warning">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($peminjamanMenunggu); ?></h4>
                            <p>Menunggu Persetujuan</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-bg-success">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($peminjamanDisetujui); ?></h4>
                            <p>Disetujui</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-check-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-bg-secondary">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($peminjamanSelesai); ?></h4>
                            <p>Selesai</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-flag-checkered fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Recent Peminjaman -->
<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Peminjaman Terbaru</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <?php if($user->isAdmin() || $user->isPetugas()): ?>
                            <th>Peminjam</th>
                        <?php endif; ?>
                        <th>Ruangan</th>
                        <th>Waktu Mulai</th>
                        <th>Waktu Selesai</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentPeminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($peminjaman->id); ?></td>
                            <?php if($user->isAdmin() || $user->isPetugas()): ?>
                                <td><?php echo e($peminjaman->user->name); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($peminjaman->ruangan->nama_ruangan); ?></td>
                            <td><?php echo e($peminjaman->waktu_mulai->format('d M Y H:i')); ?></td>
                            <td><?php echo e($peminjaman->waktu_selesai->format('d M Y H:i')); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo e($peminjaman->status); ?>">
                                    <?php echo e(ucfirst($peminjaman->status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('peminjaman.show', $peminjaman)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e($user->isAdmin() || $user->isPetugas() ? '7' : '6'); ?>" class="text-center">
                                Belum ada data peminjaman
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\FullUKK\LastUKK\resources\views\dashboard.blade.php ENDPATH**/ ?>