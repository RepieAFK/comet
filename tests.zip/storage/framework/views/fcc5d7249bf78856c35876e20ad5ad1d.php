<?php $__env->startSection('title', 'Data Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Data Peminjaman</h1>
    <a href="<?php echo e(route('peminjaman.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus me-2"></i>Ajukan Peminjaman
    </a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <?php if(auth()->user()->isAdmin() || auth()->user()->isPetugas()): ?>
                            <th>Peminjam</th>
                        <?php endif; ?>
                        <th>Ruangan</th>
                        <th>Waktu Mulai</th>
                        <th>Waktu Selesai</th>
                        <th>Keperluan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($peminjaman->id); ?></td>
                            <?php if(auth()->user()->isAdmin() || auth()->user()->isPetugas()): ?>
                                <td><?php echo e($peminjaman->user->name); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($peminjaman->ruangan->nama_ruangan); ?></td>
                            <td><?php echo e($peminjaman->waktu_mulai->format('d M Y H:i')); ?></td>
                            <td><?php echo e($peminjaman->waktu_selesai->format('d M Y H:i')); ?></td>
                            <td><?php echo e(Str::limit($peminjaman->keperluan, 50)); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo e($peminjaman->status); ?>">
                                    <?php echo e(ucfirst($peminjaman->status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('peminjaman.show', $peminjaman)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if((auth()->user()->isAdmin() || auth()->user()->isPetugas()) && $peminjaman->status == 'menunggu'): ?>
                                    <a href="<?php echo e(route('peminjaman.edit', $peminjaman)); ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                <?php endif; ?>
                                <?php if((auth()->user()->isAdmin() || auth()->user()->isPetugas()) && in_array($peminjaman->status, ['menunggu', 'disetujui'])): ?>
                                    <form action="<?php echo e(route('peminjaman.destroy', $peminjaman)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e(auth()->user()->isAdmin() || auth()->user()->isPetugas() ? '8' : '7'); ?>" class="text-center">
                                Belum ada data peminjaman
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php echo e($peminjamans->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\FullUKK\LastUKK\resources\views\peminjam\index.blade.php ENDPATH**/ ?>