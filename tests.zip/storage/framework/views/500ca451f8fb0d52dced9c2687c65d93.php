

<?php $__env->startSection('title', 'Jadwal Ruangan'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Jadwal Ruangan</h1>
    <?php if(auth()->user()->isAdmin() || auth()->user()->isPetugas()): ?>
    <a href="<?php echo e(route('jadwal_reguler.create')); ?>" class="btn btn-primary btn-sm">
        <i class="fas fa-plus fa-sm me-2"></i>Tambah Jadwal Reguler
    </a>
    <?php endif; ?>
</div>

<!-- Tabs -->
<ul class="nav nav-tabs" id="jadwalTab" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="reguler-tab" data-bs-toggle="tab" data-bs-target="#reguler" type="button" role="tab" aria-controls="reguler" aria-selected="true">Jadwal Reguler</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="peminjaman-tab" data-bs-toggle="tab" data-bs-target="#peminjaman" type="button" role="tab" aria-controls="peminjaman" aria-selected="false">Jadwal Peminjaman Minggu Ini</button>
    </li>
</ul>

<div class="tab-content" id="jadwalTabContent">
    <!-- Jadwal Reguler Tab -->
    <div class="tab-pane fade show active" id="reguler" role="tabpanel" aria-labelledby="reguler-tab">
        <div class="card shadow mt-3">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-sm">
                        <thead class="table-light">
                            <tr>
                                <th rowspan="2" style="vertical-align: middle;">Ruangan / Hari</th>
                                <th colspan="5" class="text-center">Senin - Jumat</th>
                            </tr>
                            <tr>
                                <th class="text-center">Senin</th>
                                <th class="text-center">Selasa</th>
                                <th class="text-center">Rabu</th>
                                <th class="text-center">Kamis</th>
                                <th class="text-center">Jumat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ruangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="align-middle fw-bold"><?php echo e($ruangan->nama_ruangan); ?></td>
                                <?php $__currentLoopData = $hari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <?php for($i = 1; $i <= 12; $i++): ?>
                                        <?php
                                            $key = $ruangan->id . '-' . $h . '-' . $i;
                                            $jadwal = $jadwalRegulers->get($key);
                                        ?>
                                        <?php if($jadwal): ?>
                                            <div class="alert alert-info p-1 mb-1" style="font-size: 0.75rem;">
                                                <strong>Sesi <?php echo e($i); ?></strong><br>
                                                <?php echo e($jadwal->kegiatan); ?>

                                            </div>
                                        <?php else: ?>
                                            <div class="text-muted p-1 mb-1" style="font-size: 0.75rem;">Sesi <?php echo e($i); ?> - Kosong</div>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Jadwal Peminjaman Tab -->
    <div class="tab-pane fade" id="peminjaman" role="tabpanel" aria-labelledby="peminjaman-tab">
        <div class="card shadow mt-3">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-sm">
                        <thead class="table-light">
                            <tr>
                                <th rowspan="2" style="vertical-align: middle;">Ruangan / Tanggal</th>
                                <?php
                                    $startOfWeek = now()->startOfWeek();
                                    $dates = [];
                                    for($i = 0; $i < 5; $i++) {
                                        $dates[] = $startOfWeek->copy()->addDays($i);
                                    }
                                ?>
                                <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th colspan="12" class="text-center"><?php echo e($date->format('d M')); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php for($i = 1; $i <= 12; $i++): ?>
                                        <th class="text-center" style="font-size: 0.7rem;"><?php echo e($i); ?></th>
                                    <?php endfor; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ruangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="align-middle fw-bold"><?php echo e($ruangan->nama_ruangan); ?></td>
                                <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php for($i = 1; $i <= 12; $i++): ?>
                                        <?php
                                            $key = $ruangan->id . '-' . $date->format('Y-m-d') . '-' . $i;
                                            $peminjaman = $peminjamans->get($key);
                                        ?>
                                        <td class="text-center p-1" style="font-size: 0.7rem;">
                                            <?php if($peminjaman): ?>
                                                <div class="alert alert-warning p-1 mb-0" style="font-size: 0.6rem; cursor: pointer;" 
                                                     title="<?php echo e($peminjaman->user->name); ?> - <?php echo e($peminjaman->keperluan); ?>">
                                                    <i class="fas fa-user"></i>
                                                </div>
                                            <?php else: ?>
                                                <div class="text-muted">-</div>
                                            <?php endif; ?>
                                        </td>
                                    <?php endfor; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\FullUKK\LastUKK\resources\views\jadwal\reguler_index.blade.php ENDPATH**/ ?>